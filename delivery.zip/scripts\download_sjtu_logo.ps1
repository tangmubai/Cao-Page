# 下载上海交通大学官网视觉库中的横版校标（英文横版）并保存为 assets/sjtu-logo.png
# 来源页面： https://vi.sjtu.edu.cn/index.php/articles/bulletin/13

$sourceUrl = 'https://vi.sjtu.edu.cn/index.php/downloads/attachments/129'
$destPath = Join-Path -Path (Split-Path -Parent $MyInvocation.MyCommand.Path) -ChildPath "..\assets\sjtu-logo.png"

Write-Host "Downloading logo from: $sourceUrl"
Write-Host "Saving to: $destPath"

try {
    Invoke-WebRequest -Uri $sourceUrl -OutFile $destPath -UseBasicParsing -ErrorAction Stop
    Write-Host "下载完成 -> $destPath"
} catch {
    Write-Error "下载失败：$($_.Exception.Message)"
    Write-Host "你可以在浏览器中打开 https://vi.sjtu.edu.cn/index.php/articles/bulletin/13 手动下载所需文件，然后放到 assets/ 目录并命名为 sjtu-logo.png"
}
